#!/usr/bin/python3
#Já que ela deve ser ordenada a cada inserção, a forma mais eficiente é a que faz o menor número de comparações para um lista que teoricamente já estará ordenada, pois a cada inserção a lista lista é ordenada.
def insertion_sort(lista):
	for i in range(1, len(lista)):
		aux = i
		while lista[aux-1] > lista[aux]:
			lista[aux-1],lista[aux] = lista[aux],lista[aux-1]
			if aux > 1:
				aux-=1
	return lista
	
def agendaTelefonica():
	data = [("nicholas", 666), ("eduardo", 616), ("lucas",166), ("gean",166)]
	agenda = []
	#inserir em Agenda 
	for x in range(len(data)):
		agenda.append(data[x])
		agenda = insertion_sort(agenda)
		print(agenda)

agendaTelefonica()
